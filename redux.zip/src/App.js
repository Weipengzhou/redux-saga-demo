import React, { Component } from 'react';
import { connect } from 'react-redux';
import action from './redux/action';
import './App.css';

class App extends Component {

  addClick=()=>{
    this.props.add( this.props.value + 1)
  }
  jianClick = () => {
    this.props.jian( this.props.value - 1)
  }
  render() {
    const {value}= this.props;
    return (
      <div className="App">
             <p>{value}</p>
            <button onClick={this.addClick.bind(this)}>+</button>
            <button onClick={this.jianClick.bind(this)}>-</button>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return { value:state.value  }
}

function mapDispatchToProps(dispatch) {
  return {
    add: (event) => dispatch(action.buttonAdd(event)),
    jian:(event) => dispatch(action.buttonJian(event)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
