let actions = {
    buttonAdd: function (text) {
        return {
            type: 'BUTTON_CLICK_ADD',
            text
        }
    },
    buttonJian:function(text){
        return {
            type: 'BUTTON_CLICK_JIAN',
            text
        }
    }
}
export default actions;