import { applyMiddleware, createStore} from 'redux';
import reducers from './reducer';
import thunk from 'redux-thunk';

export default function configureStore(init) {
    const store = createStore(reducers, init, applyMiddleware(thunk));
    return store;
}